package com.psicocare.DAO;

public class C {

}
